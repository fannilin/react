import React from "react";
import LomakeMUI from './mui/LomakeMUI';

  

  function App() {
    return (
      <div>
    <LomakeMUI/>
    </div> 
        
    );
  }

export default App;
