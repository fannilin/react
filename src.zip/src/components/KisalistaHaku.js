
import React, {useState} from 'react';

function KisalistaHaku () {
    const [kilpailu, setKilpailu ]= useState( {
        paikka: '',
        hevonen: '',
        paiva: '',
        taso: '',
        tulos: '',
        kuvaus: '',
    } );
    const[virhe, setVirhe] = useState('');
    const[paikka, setPaikka] = useState('');

    const fetchUrl = async () => {
        try {
            const response = await fetch('http://localhost:8080/kilpailu/all'+ paikka );
            const json = await response.json();
            setKilpailu(
                {
                    paikka: json.paikka,
                    hevonen: json.hevonen,
                    paiva: json.paiva,
                    taso: json.taso,
                    tulos: json.tulos,
                    kuvaus: json.kuvaus
                }
            );
            setVirhe('');
        } catch (error) {
            setVirhe('Haku ei onnistunut.');
        }
    }

    const hae = (e) => {
        if (paikka.length > 0) {
            fetchUrl();
        } else {
            setVirhe('Anna paikka');
        }
    }

    return (
        <div>
            <form>
                <label htmlFor='paikka'>Paikka</label>&nbsp;
                <input type='text' name='paikka' id='paikka' value={ paikka } 
                       onChange={ (e) => setPaikka(e.target.value) } />&nbsp;
                <input type='button' name='hae' value='Hae' onClick={ (e) =>  hae(e)  } />
            </form>
            {
                kilpailu.paikka.length > 0 && virhe.length === 0 ?
                <div>
                    <h3>{ kilpailu.paikka }</h3>
                    { kilpailu.hevonen } <br/>
                    { kilpailu.paiva } &#8451;<br />
                    { kilpailu.taso } <br />
                    { kilpailu.tulos } <br/>
                    { kilpailu.kuvaus }
                </div>
                : <p>{ virhe }</p>
            }          
        </div>
    );
}
export default KisalistaHaku;