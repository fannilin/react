
import React, { useState } from 'react';
import Box from '@mui/material/Box';
import Drawer from '@mui/material/Drawer';
import IconButton from '@mui/material/IconButton';
import List from '@mui/material/List';
import ListItem from '@mui/material/ListItem';
import ListItemText from '@mui/material/ListItemText';
import ListItemIcon from '@mui/material/ListItemIcon';
import CreateIcon from '@mui/icons-material/Create';
import MenuIcon from '@mui/icons-material/Menu';
import HomeIcon from '@mui/icons-material/Home';
import { Link, Outlet } from 'react-router-dom';
import FavoriteIcon from '@mui/icons-material/Favorite';


function DrawerMUI () {

  const [open, setOpen ] = useState(false);

  const handleOpen = () => { 
    setOpen(true); 
  }

  const handleClose = () => { 
    setOpen(false); 
  }

  return (
    <Box>
       <IconButton onClick={ handleOpen } color='inherit'><MenuIcon /></IconButton>
<Drawer anchor='left' open={ open } onClick={ handleClose }>
   <List>
    <ListItem component= { Link } to='lista' button>
    <ListItemIcon ><HomeIcon color='primary'/></ListItemIcon>
   <ListItemText primary='Kilpailulista'  />
  </ListItem>
  <ListItem component= { Link } to='lomake' button>
  <ListItemIcon  ><CreateIcon color='primary'/></ListItemIcon>
  <ListItemText primary='Lisää uusi' />
   </ListItem>
    <ListItem component= { Link } to='hepat' button>
  <ListItemIcon ><FavoriteIcon color='primary' /></ListItemIcon>
    <ListItemText primary='Hevoset' />
   </ListItem>
  <ListItem component= { Link } to='pro' button>
  <ListItemIcon ><MenuIcon color='primary' /></ListItemIcon>
  <ListItemText primary='Projektista' />
  </ListItem>
  </List>
</Drawer>
<Outlet />
</Box> 
    
  );
}

export default DrawerMUI;