import React, {useState} from 'react';
import Box from '@mui/material/Box';
import AppBar from '@mui/material/AppBar';
import Toolbar from '@mui/material/Toolbar';
import Typography from '@mui/material/Typography';
import Tabs from '@mui/material/Tabs';
import Tab from '@mui/material/Tab';
import Avatar from '@mui/material/Avatar';
import Link from '@mui/material/Link';
import { Card, CardContent, CardMedia } from '@mui/material';


function ProjektiMUI () {
 

  return (
    <Box>
     
    

      
      <Card maxWidth='400' sx={ { padding:8} }>
        <CardMedia><Avatar alt="avatar" src="/kuvia/fanni.jpg" sx= {{ width: 200, height: 200 }}/></CardMedia>

      <CardContent>
        <h3>Fannin kilpailut sovellus, harjoitustyön 3-osa.
        </h3>
      <Typography> Reactin perusteet, MUI ja React Router yhdistettynä</Typography>
      <Typography>Tekijä: Fanni Lindqvist</Typography>
      <Typography>Alla olevista linkeistä lisää tietoa lajista</Typography>
     
   
    <Link href="https://www.ratsastus.fi/" target="_blank" rel="noreferrer" style={{ marginRight: 20}} >
      Ratsastus.fi
    </Link>

    <Link href="https://online.equipe.com/" target="_blank" rel="noreferrer" style={{ marginRight: 20}} >
      Equipe Online
    </Link>

    <Link href="https://kipa.ratsastus.fi/" target="_blank" rel="noreferrer" style={{ marginRight: 20}} > 
      Kipa-Kilpailupalvelut
    </Link>
   
   
      </CardContent>
    </Card>
   
  </Box>
  )
}

export default ProjektiMUI;
