


export const SliderData = [
    {
        image: '/kuvia/laidun.jpg',
    },
    {
        image: '/kuvia/novassa.jpg',
    },
    {
        image: '/kuvia/messuilla.jpg',
    },
    {
        image: '/kuvia/radalla.jpg',
    },
    {
        image: '/kuvia/ainossa.jpg',
    },
];