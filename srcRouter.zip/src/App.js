import { ThemeProvider, createTheme, CssBaseline } from "@mui/material";
import React from "react";
import { lightBlue, amber, brown, red } from "@mui/material/colors";
import TabsMUI from "./mui/TabsMUI";
import Typography from "@mui/material/Typography";
import Button from "@mui/material/Button";
import { BrowserRouter, Routes, Route } from 'react-router-dom';
import Tieto from "./components/Tieto";
import LomakeMUI from "./mui/LomakeMUI";
import MenuMUI from "./mui/MenuMUI";
import Resepti from "./components/Resepti";
import DrawerMUI from "./mui/DrawerMUI";
import HeppaCardMUI from "./mui/HeppaCardMUI";


const hevonen = [
  {
    id: 1,
    nimi: 'Commando',
    lempinimi: 'Kamu',
    syntynyt: '2005',
    rotu: 'Tanskalainen puoliverinen',
    sukupuoli: 'ruuna',
    kuva: 'kamu.jpg'
  },
  {
    id: 2,
    nimi: 'Luciferina LH',
    lempinimi: 'Luci',
    syntynyt: '2012',
    rotu: 'Holstainer',
    sukupuoli: 'tamma',
    kuva: 'luci.jpg'
  }
];



const theme = createTheme ({
palette: {
  primary: {main: lightBlue[500], contrastText: '#FFFFFF'},
  secondary: {main: amber[300], contrastText: lightBlue[50]},
  text: {primary: lightBlue[500], secondary: brown[50] },
  typography: {fontFamily: "'Poppins' , 'sans-serif'"}
  }
}
);


  function App() {
    return (
      <ThemeProvider theme={ theme }>
        <CssBaseline/>
        
        <BrowserRouter>
        <Routes>
<Route path='/' element={ <DrawerMUI /> }>
<Route index element={  <Typography>Fannin harjoitukset</Typography>}/>
<Route path='tietoja' element={ <Tieto /> } />
<Route path='lomake' element={ <LomakeMUI /> } />
<Route path='resepti' element={ <Resepti /> }/>
<Route path='menu' element={ <MenuMUI /> } />
<Route path='*' element={ <Tieto/> } />
</Route>
</Routes>
</BrowserRouter>

    </ThemeProvider>  
    );
  }

export default App;
